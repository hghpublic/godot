@tool
extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass


var size = Vector2(10,640)

func _draw() -> void:

	var rect = Rect2(position, size)
	draw_rect(rect, Color.GRAY)
