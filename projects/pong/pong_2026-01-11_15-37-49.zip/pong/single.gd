@tool
extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass

func _init() -> void:
	if not is_inside_tree():
		return
		
	var tree = get_tree()
	
	if tree:
		tree.reload_current_scene()
