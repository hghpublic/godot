extends Node2D

var circles : Array = []
const MAX_NUM_CIRCLES = 500

var color = Color.RED
var radius = 5

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.

func _input(event: InputEvent) -> void:
	
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		circles.clear()
		queue_redraw()
		return
	elif not Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		return
	
	while circles.size() >= MAX_NUM_CIRCLES:
		circles.pop_front()
	
	circles.append(event.position)
	
	queue_redraw()
	
func _draw() -> void:
	
	for c in circles:
		draw_circle(c, radius, color)
	
		
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
